Build:  ./gradlew shadowJar   (needs Java 25)
Output: build/libs/*.jar  -> put in server plugins/
Config: plugins/AxiomPaper/config.yml -> unsupported-axiom-version: "ignore"
Patch: HelloPacketListener.java (accept older Axiom client API versions)
